package com.metabuild.chargeup.dto;

import lombok.Data;

@Data
public class CombinedDTO {
    private ReserveInfoDTO reserve;
    private ChargeInfoDTO charge;

    public CombinedDTO() {}

    public CombinedDTO(ReserveInfoDTO reserveInfoDTO, ChargeInfoDTO chargeInfoDTO) {
        reserve = reserveInfoDTO;
        charge = chargeInfoDTO;
    }
}