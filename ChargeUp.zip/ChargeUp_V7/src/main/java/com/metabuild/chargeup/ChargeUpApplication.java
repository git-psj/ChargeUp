package com.metabuild.chargeup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChargeUpApplication {

	public static void main(String[] args) {

		SpringApplication.run(ChargeUpApplication.class, args);
	}

}
