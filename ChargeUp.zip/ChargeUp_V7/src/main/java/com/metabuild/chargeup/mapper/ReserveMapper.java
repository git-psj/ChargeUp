package com.metabuild.chargeup.mapper;

import com.metabuild.chargeup.dto.ReserveInfoDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ReserveMapper {

    // 예약 정보 삽입
    int insertReservation(ReserveInfoDTO reservation);

    // 중복 예약 확인
    int checkDuplicateReservation(
            @Param("statId") String statId,
            @Param("chgerid") String chgerid,
            @Param("reserveDate") String reserveDate,
            @Param("reserveTime") String reserveTime,
            @Param("reservationId") String reservationId
    );

    // 특정 충전소와 충전기의 예약 정보 조회
    @Select("SELECT * FROM reservations WHERE statid = #{statid} AND chgerid = #{chgerid}")
    @ResultMap("ReserveInfoResultMap")
    List<ReserveInfoDTO> getReservationByStatAndChger(
            @Param("statid") String statid,
            @Param("chgerid") String chgerid
    );
}