package com.metabuild.chargeup.controller;

import com.metabuild.chargeup.NoMemberException;
import com.metabuild.chargeup.dto.CombinedDTO;
import com.metabuild.chargeup.dto.PagingDTO;
import com.metabuild.chargeup.dto.ReserveInfoDTO;
import com.metabuild.chargeup.dto.UserDTO;
import com.metabuild.chargeup.service.UserService;
import jakarta.inject.Inject;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Slf4j
@Controller
public class UserController {

    @Inject
    private UserService userService;


    @GetMapping("/login") // 로그인
    public String showloginPage(){
        return "user/login";
    }
    @GetMapping("/signup") // 회원가입
    public String showSignUpPage(){
        return "user/signup";
    }
    @GetMapping("/idCheck") // 아이디확인창
    public String showIdPage(){
        return "user/idCheck";
    }
    
    @GetMapping("/myPage") // 마이페이지
    public String showMyPage(Model model, HttpSession session){
        UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
        model.addAttribute("loginUser", loginUser);
        return "myPage";
    }
    
    // 아이디 중복 확인
    @RequestMapping(value="/idCheck", method = RequestMethod.POST)
    public String idCheckResult(Model model, @RequestParam(defaultValue = "") String userId){
        log.info("userId===={}", userId);
        if(userId.trim().isBlank()){
            model.addAttribute("message","아이디 입력하세요");
            model.addAttribute("loc","javascript:history.back()");
            return "message";
        }

        boolean isUse=userService.idCheck(userId.trim());
        log.debug("$isUser === {}", isUse);
        String str=(isUse)? userId+"는 사용 가능합니다": userId+"는 이미 사용 중 입니다";
        String result=(isUse)? "ok":"fail";

        model.addAttribute("message",str);
        model.addAttribute("result", result);
        model.addAttribute("userId", userId);
        return "user/idCheckResult";
    }
    
    // 회원가입
    @RequestMapping(value="/signupProc", method = RequestMethod.POST)
    public String signupProcess(UserDTO user, Model model){
        //html의 input name과 DTO의 property명이 같으면 자동으로 DTO객체에 담아준다
        log.info("MemberDTO user====={}", user);
        //[1] 유효성 체크 (userId,name,passwd) ----
        if(user.getUserId().trim().isBlank()||user.getPassword().trim().isBlank()
                ||user.getName().trim().isBlank()){
            return "redirect:signup";
        }

        //[2] memberService의 insertMember(user)호출
        int n=userService.insertMember(user);
        log.debug("$$n  == {}", n);
        //[3] 실행결과 메시지,이동할 경로 지정
        String str=(n>0)? "회원가입 완료!! 로그인 페이지로 이동합니다":"회원가입 실패-아이디 중복체크 확인하세요";
        String loc=(n>0)? "login":"javascript:history.back()";

        model.addAttribute("message",str);
        model.addAttribute("loc",loc);
        return "message";
    }
    @PostMapping("/login") // 로그인
    public String loginProcess(UserDTO tmpUser,
                               @RequestParam(name="saveId", defaultValue = "false") boolean saveId
            , HttpSession session, HttpServletResponse response, RedirectAttributes redirectAttributes)
            throws NoMemberException
    {
        log.info("tmpUser==={}", tmpUser);
        log.info("saveId==={}",saveId);
        try{
            UserDTO authUser=userService.loginCheck(tmpUser);
            if(authUser!=null){
                log.info("회원 인증 성공!!");
                session.setAttribute("loginUser", authUser);
                String sessionId=session.getId();
                log.info("sessionId======{}",sessionId);

                Cookie cookie=new Cookie("uid", authUser.getUserId());
                if(saveId){//아이디 저장에 체크한 경우
                    cookie.setMaxAge(60*60*24*7);//유효시간 설정. 7일간 유효하도록 설정
                }else{//체크하지 않은 경우
                    cookie.setMaxAge(0); //쿠키 삭제
                }
                cookie.setPath("/");//쿠키를 꺼낼 수 있는 경로 "/" 설정
                //응답 객체에 쿠키를 추가==> 응답데이터 헤더에 쿠키가 저장
                response.addCookie(cookie);
            }
            return "redirect:/myReservation";
        } catch (NoMemberException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/login";
        }
    }
    @GetMapping("/logout") // 로그아웃
    public String logout(HttpSession session){
        // 모든 세션 변수 삭제
        session.invalidate();
        return "redirect:/search";
    }


    @GetMapping("/myReservation") // 예약정보 조회
    public String boardList(HttpSession session, Model model, PagingDTO paging){
        //1. 총 예약 건수 가져오기
        UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
        log.info("session===={}", loginUser);
        int totalCount = userService.getTotalCount(loginUser.getUserId());

        paging.setTotalCount(totalCount);//총 게시글 수 설정
        paging.setPageSize(10);//한 페이지 당 보여줄 목록 개수 5로 설정
        paging.setPagingBlock(5);
        paging.init();//페이징 처리 관련 연산을 수행하는 메서드 호출
        log.info("paging==={}",paging);

        List<CombinedDTO> dto = userService.findReserve(loginUser.getUserId(), paging);
        log.debug("dto=============={}", dto);
        //3. 페이징 처리 문자열 받아오기
        String myctx="", loc="myReservation";
        String pageStr=paging.getPageNavi(myctx, loc);

        model.addAttribute("pageNavi", pageStr);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("reservationDTO", dto);
        model.addAttribute("paging", paging);
        return "myReservation";//자바로 페이지 네비게이션 구현
    }
    @PostMapping("/delete") // 예약 삭제
    public String boardDelete(@ModelAttribute ReserveInfoDTO dto){
        int n = userService.deleteReserve(dto);
        log.debug("$n=========={}", n);
        return "redirect:myReservation";
    }

    @PostMapping("/deleteUser") // 사용자 삭제
    public String userDelete(@RequestParam("userId") String userId, HttpSession session){
        log.debug("삭제----");
        UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
        log.debug("loginUser===={}", loginUser);
        // 현재 로그인한 사용자와 요청한 userId가 다르면 탈퇴 요청을 거부
        if (!loginUser.getUserId().equals(userId)) {
            log.debug("같지않음");
            return "redirect:login";
        }
        log.debug("같음");
        int n = userService.deleteMember(userId);
        log.debug("n===={}", n);
        session.invalidate();
        return "redirect:search";
    }
}
