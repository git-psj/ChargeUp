package com.metabuild.chargeup.service;

import com.metabuild.chargeup.NoMemberException;
import com.metabuild.chargeup.dto.CombinedDTO;
import com.metabuild.chargeup.dto.PagingDTO;
import com.metabuild.chargeup.dto.ReserveInfoDTO;
import com.metabuild.chargeup.dto.UserDTO;

import java.util.List;


public interface UserService {
    int insertMember(UserDTO user);//회원등록
    int deleteMember(String userId);
    UserDTO findByUserId(String userId);
    boolean idCheck(String userId);
    UserDTO loginCheck(UserDTO tmpUser) throws NoMemberException;
    List<CombinedDTO> findReserve(String userId, PagingDTO paging);
    int getTotalCount(String userId);
    int deleteReserve(ReserveInfoDTO dto);
}
