package com.metabuild.chargeup.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Service
public class GeocodingService {

    private static final String GEOCODING_API_URL = "https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode";
    private static final String API_KEY_ID = "8pucnfsgln"; // 네이버 API 키 ID
    private static final String API_KEY = "fezDUm7zaixxCCbJ2vmqThtdDqnxpRgYYmEOwKuC"; // 네이버 API 키

    public String[] getCoordinates(String address) {
        RestTemplate restTemplate = new RestTemplate();
        String url = GEOCODING_API_URL + "?query=" + URLEncoder.encode(address, StandardCharsets.UTF_8);

        // API 키 추가
        HttpHeaders headers = new HttpHeaders();
        headers.set("x-ncp-apigw-api-key-id", API_KEY_ID);
        headers.set("x-ncp-apigw-api-key", API_KEY);

        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        String body = response.getBody();
        try {
            // JSON 응답 파싱
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(body);

            JsonNode addressesNode = rootNode.path("addresses");
            if (addressesNode.isArray() && !addressesNode.isEmpty()) {
                JsonNode addressNode = addressesNode.get(0);
                String x = addressNode.path("x").asText();
                String y = addressNode.path("y").asText();
                return new String[]{x, y};
            } else {
                throw new RuntimeException("Geocoding API에서 결과를 찾을 수 없습니다.");
            }
        } catch (Exception e) {
            throw new RuntimeException("Geocoding API 응답 처리 중 오류 발생", e);
        }
    }
}
