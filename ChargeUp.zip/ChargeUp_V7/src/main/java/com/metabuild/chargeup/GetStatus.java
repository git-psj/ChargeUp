package com.metabuild.chargeup;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetStatus
{
    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException
    {
        System.out.println(getStatus("ME174013"));
    }

    public static List<Map<Integer, Map<String, String>>> getStatus(String id) throws IOException, ParserConfigurationException, SAXException
    {
        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/B552584/EvCharger/getChargerInfo"); /*URL*/
//        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/B552584/EvCharger/getChargerStatus"); /*URL*/
        urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=5PI1MfqlBzT6Wm%2F9lzL%2B316eFC35J2W5PqxjGoBSJxSQ9O5%2FCu%2F5J34wrCWMCdSVjEuQ2KwzPTp7rXid73vZXQ%3D%3D"); /*Service Key*/
        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지 번호*/
        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("100", "UTF-8")); /*한 페이지 결과 수 (최소 10, 최대 9999)*/
        urlBuilder.append("&" + URLEncoder.encode("statId","UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"));
//        urlBuilder.append("&" + URLEncoder.encode("chgerId","UTF-8") + "=" + URLEncoder.encode(num, "UTF-8"));
//        urlBuilder.append("&" + URLEncoder.encode("dataType","UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8"));

        URL url = new URL(urlBuilder.toString());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
//        System.out.println("Response code: " + conn.getResponseCode());
        BufferedReader rd;
        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();
        conn.disconnect();
//        System.out.println(sb.toString());

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        String xml = sb.toString();
        Document document = builder.parse(new InputSource(new StringReader(xml)));
//
        NodeList items = document.getElementsByTagName("item");

        List<Map<Integer, Map<String, String>>> list = new ArrayList<>();

        for (int i = 0; i < items.getLength(); i++)
        {
            Element item = (Element) items.item(i);

            String stat = item.getElementsByTagName("stat").item(0).getTextContent();
            String statUpdDt = item.getElementsByTagName("statUpdDt").item(0).getTextContent();
//            String lastTsdt = item.getElementsByTagName("lastTsdt").item(0).getTextContent();
//            String lastTedt = item.getElementsByTagName("lastTedt").item(0).getTextContent();
            String nowTsdt = item.getElementsByTagName("nowTsdt").item(0).getTextContent();

            Map<Integer, Map<String, String>> listmap = new HashMap<>();
            Map<String, String> datamap = new HashMap<>();

            datamap.put("stat", stat);
            datamap.put("statUpdDt", statUpdDt);
            datamap.put("nowTsdt", nowTsdt);

            listmap.put(i+1, datamap);

            list.add(listmap);
       }

        return list;
    }
}

