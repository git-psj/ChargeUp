package com.metabuild.chargeup.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String userId;
    private String password;
    private String name;
    private String hp1;
    private String hp2;
    private String hp3;
    private String sdate;
    public String getAllHp(){
        return hp1+"-"+hp2+"-"+hp3;
    }
}
