package com.metabuild.chargeup.controller;

import com.metabuild.chargeup.service.GeocodingService;
import com.metabuild.chargeup.service.RouteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Slf4j
@RestController
public class RouteController {

    private final GeocodingService geocodingService;


    @Autowired
    private RouteService routeService;

    @Autowired
    public RouteController(GeocodingService geocodingService) {
        this.geocodingService = geocodingService;
    }

//    @GetMapping("/coordinates")
//    public String[] getCoordinates(@RequestParam String address) {
//        return geocodingService.getCoordinates(address);
//    }

    @GetMapping("/route")
    public String getRoute(
            @RequestParam String start,
            @RequestParam String goal,
            @RequestParam(required = false) String startCoordinate,
            @RequestParam(required = false) String goalCoordinate
    ) {
        return routeService.findRoute(start, goal, startCoordinate, goalCoordinate);
    }

    @PostMapping("/coordinates")
    public String getCoordinates(@RequestBody Map<String, Map<String, Double>> geoData) {
        log.debug("포스트=={}", geoData);
        Map<String, Double> start = geoData.get("start");  // 시작 좌표 객체
        Map<String, Double> goal = geoData.get("goal");    // 목표 좌표 객체

        // 좌표 처리 로직 (예시: 단순 출력)
        log.debug("Start Coordinates: " + start);
        log.debug("Goal Coordinates: " + goal);

//        return "test";
        return routeService.find(start, goal);
    }

}