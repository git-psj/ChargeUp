package com.metabuild.chargeup.dto;

public class SearchResultDTO {
    private int id;
    private String title;
    private String address;
    private String mapx;
    private String mapy;

    public SearchResultDTO(int id, String title, String address, String mapx, String mapy) {
        this.id = id;
        this.title = title;
        this.address = address;
        this.mapx = mapx;
        this.mapy = mapy;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAddress() { return address; }
    public String getMapx() { return mapx; }
    public String getMapy() { return mapy; }
}
