package com.metabuild.chargeup.mapper;

import com.metabuild.chargeup.dto.ChargeInfoDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Mapper
public interface chargeMapper {
    // 시도 정보 가져오기
    List<Map<String, String>> getSidoCode();
    // 시도로 시군구 가져오기
    List<Map<String, String>> getSigunguCode(String sidoCode);
    // 지역 코드 검색에 따른 결과
    List<ChargeInfoDTO> getStationByZscode(String zscode);

    // statid로 충전소 정보 조회
    List<ChargeInfoDTO> getChargeInfo(String statId);
    List<ChargeInfoDTO> getCharges(List<String> listStatId);
    // 필터 적용 결과
    List<Map<String, Object>> getStationByFilter(HashMap<String, Object> filter);
    // 주소 검색에 따른 결과
    List<ChargeInfoDTO> getStationsByAddr(String addr);
    // 충전소명 검색에 따른 결과
    List<ChargeInfoDTO> getStationByStatNm(String statNm);
}
