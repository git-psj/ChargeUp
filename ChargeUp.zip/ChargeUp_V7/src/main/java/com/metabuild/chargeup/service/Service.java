package com.metabuild.chargeup.service;

import com.metabuild.chargeup.dto.ChargeInfoDTO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface Service {
    List<ChargeInfoDTO> getStationsByAddr(String addr);
    List<ChargeInfoDTO> getStationByStatNm(String statNm);
    List<Map<String, Object>> getStationByFilter(HashMap<String, Object> filter);
    List<Map<String, String>> getSidoCode();
    List<Map<String, String>> getSigunguCode(String sidoCode);
    List<ChargeInfoDTO> getStationByZscode(String zscode);
    List<ChargeInfoDTO> getChargeInfo(String statId);
    List<ChargeInfoDTO> getCharges(List<String> listStatId);
}
