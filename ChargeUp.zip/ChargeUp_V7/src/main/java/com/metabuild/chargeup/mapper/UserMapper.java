package com.metabuild.chargeup.mapper;

import com.metabuild.chargeup.dto.CombinedDTO;
import com.metabuild.chargeup.dto.PagingDTO;
import com.metabuild.chargeup.dto.ReserveInfoDTO;
import com.metabuild.chargeup.dto.UserDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {
    int insertMember(UserDTO user);//회원등록
    int deleteMember(String userId);
    UserDTO findByUserId(String userId);
    List<CombinedDTO>  findReserve(@Param("userId") String userId, @Param("paging")PagingDTO paging);
    int getTotalCount(String userId);
    int deleteReserve(ReserveInfoDTO dto);
}
