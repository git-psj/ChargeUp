package com.metabuild.chargeup.dto;

import lombok.Data;

@Data
public class ChargeInfoDTO {
    private int count;
    private String statNm;
    private String statId;
    private String chgerId;
    private String chgerType;
    private String addr;
    private String addrDetail;
    private String location;
    private String lat;
    private String lng;
    private String useTime;
    private String busiId;
    private String bnm;
    private String busiNm;
    private String busiCall;
    private String stat;
    private String statUpdDt;
    private String lastTsDt;
    private String lastTeDt;
    private String nowTsDt;
    private String powerType;
    private String output;
    private String method;
    private String zcode;
    private String zscode;
    private String kind;
    private String kindDetail;
    private String parkingFree;
    private String note;
    private String limitYn;
    private String limitDetail;
    private String delYn;
    private String delDetail;

    private String userId;
    private String rdate;
    private String time;
    private String rdatetime;

    public void setOtherInfo(ChargeInfoDTO other) {
        if (other == null) {
            return;
        }

        // 현재 객체에 null이거나 빈 값인 필드에만 other 객체의 값을 설정
        if (this.statNm == null || this.statNm.isEmpty()) this.statNm = other.getStatNm();
        if (this.addr == null || this.addr.isEmpty()) this.addr = other.getAddr();
        if (this.addrDetail == null || this.addrDetail.isEmpty()) this.addrDetail = other.getAddrDetail();
        if (this.location == null || this.location.isEmpty()) this.location = other.getLocation();
        if (this.lat == null || this.lat.isEmpty()) this.lat = other.getLat();
        if (this.lng == null || this.lng.isEmpty()) this.lng = other.getLng();
        if (this.useTime == null || this.useTime.isEmpty()) this.useTime = other.getUseTime();
        if (this.busiNm == null || this.busiNm.isEmpty()) this.busiNm = other.getBusiNm();
        if (this.busiCall == null || this.busiCall.isEmpty()) this.busiCall = other.getBusiCall();
        if (this.note == null || this.note.isEmpty()) this.note = other.getNote();
        // 필요한 다른 필드도 동일한 방식으로 설정 가능
    }

}
