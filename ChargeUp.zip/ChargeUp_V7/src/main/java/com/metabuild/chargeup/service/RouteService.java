package com.metabuild.chargeup.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Slf4j
@Service
public class RouteService {

    private final String API_KEY_ID = "r8lxg4eq75";
    private final String API_KEY = "THswmnlTeAaLPvEV4CiYsQh2fWNCotTpFPcJHTvy";
    private final String GEOCODING_API_URL = "https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode";
    private final String DIRECTIONS_API_URL = "https://naveropenapi.apigw.ntruss.com/map-direction/v1/driving";

    public String findRoute(String start, String goal, String startCoordinate, String goalCoordinate) {
        try {
            // 출발지와 도착지의 좌표를 가져옴 (coordinate 활용)
//            String[] startCoords = getCoordinates(start, startCoordinate);
//            String[] goalCoords = getCoordinates(goal, goalCoordinate);
//            log.debug("$$$좌표===={}", startCoords, goalCoords);
//            log.debug("$$$좌표===={}{}", startCoords, goalCoords);
            String[] startCoords = new String[]{"127.0160375", "37.4830098"};
//            String[] startCoords = new String[]{"37.4830098", "127.0160375"};
//            String[] goalCoords = new String[]{"37.484765", "127.015851"};
            String[] goalCoords = new String[]{"127.015851", "37.484765"};
            // 경로 정보 가져오기
//            return getDirections(startCoords, goalCoords);
            return "test";
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"Failed to fetch route data\"}";
        }
    }

//    private String[] getCoordinates(String address, String coordinate) {
//        RestTemplate restTemplate = new RestTemplate();
//        log.debug("주소=={}", address);
//        String url = GEOCODING_API_URL + "?query=" + URLEncoder.encode(address, StandardCharsets.UTF_8);
//
//        log.debug("좌표 구하기=={}", url);
//        // coordinate 값이 주어진 경우 URL에 추가
//        if (coordinate != null && !coordinate.isEmpty()) {
//            url += "&coordinate=" + coordinate;
//        }
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.set("x-ncp-apigw-api-key-id",API_KEY_ID);
//        headers.set("x-ncp-apigw-api-key",API_KEY);
//        headers.set("Accept", "application/json");
//        log.debug("좌표 headers=={}", headers);
//        HttpEntity<String> entity = new HttpEntity<>(headers);
//        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
//
//        String body = response.getBody();
//        log.debug("좌표 구하기body=={}", body);
//        log.debug("좌표 entity=={}", entity);
//        log.debug("좌표 response=={}", response);
//        try {
//            // JSON 응답 파싱
//            ObjectMapper objectMapper = new ObjectMapper();
//            JsonNode rootNode = objectMapper.readTree(body);
//
//            // 유효성 검증: addresses 배열이 비어 있으면 예외 발생
//            JsonNode addressesNode = rootNode.path("addresses");
//            if (!addressesNode.isArray() || addressesNode.size() == 0) {
//                throw new RuntimeException("Geocoding API에서 결과를 찾을 수 없습니다: " + address);
//            }
//
//            JsonNode addressNode = addressesNode.get(0); // 가장 근접한 주소를 선택
//            String x = addressNode.path("x").asText();
//            String y = addressNode.path("y").asText();
//            log.debug("좌표 x, y=={} {}", x, y);
//            return new String[]{x, y};
//        } catch (Exception e) {
//            throw new RuntimeException("Geocoding API 응답 처리 중 오류 발생: " + body, e);
//        }
//    }


    public String find(Map<String, Double> start, Map<String, Double> goal) {
        try {
            return getDirections(start, goal);
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"Failed to fetch route data\"}";
        }
    }
    private String getDirections(Map<String, Double> startCoords, Map<String, Double> goalCoords) {
        RestTemplate restTemplate = new RestTemplate();
        String url = DIRECTIONS_API_URL + "?start=" + startCoords.get("lng") + "," + startCoords.get("lat")
                + "&goal=" + goalCoords.get("lng") + "," + goalCoords.get("lat") + "&option=traoptimal";
        log.debug("url==={}", url);
        HttpHeaders headers = new HttpHeaders();
        headers.set("x-ncp-apigw-api-key-id", API_KEY_ID);
        headers.set("x-ncp-apigw-api-key", API_KEY);

        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        return response.getBody();
    }
}

