package com.metabuild.chargeup.controller;

import com.metabuild.chargeup.dto.SearchResultDTO;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    private final WebClient webClient;
    private static final List<SearchResultDTO> selectedResults = Collections.synchronizedList(new ArrayList<>());

    public SearchController(WebClient webClient) {
        this.webClient = webClient;
    }

    // 🔹 1. 네이버 API에서 5개 검색 결과 가져오기 (검색어 미입력 시 예외 처리)
    @GetMapping(value = "", produces = "application/json; charset=UTF-8")
    public ResponseEntity<?> search(@RequestParam(name = "text") String text) {
        if (text == null || text.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("❌ 검색어를 입력하세요.");
        }

        try {
            URI uri = UriComponentsBuilder
                    .fromUriString("https://openapi.naver.com")
                    .path("/v1/search/local.json")
                    .queryParam("query", text)
                    .queryParam("display", 5) // 🔹 검색 결과 5개 반환
                    .queryParam("start", 1)
                    .queryParam("sort", "random")
                    .encode(StandardCharsets.UTF_8)
                    .build()
                    .toUri();

            ResponseEntity<String> responseEntity = webClient.get()
                    .uri(uri)
                    .retrieve()
                    .toEntity(String.class)
                    .block();

            String responseBody = responseEntity.getBody();
            List<SearchResultDTO> results = parseResults(responseBody);

            return ResponseEntity.ok(results);

        } catch (WebClientResponseException e) {
            return handleApiException(e);
        }
    }

    // 🔹 2. JSON 응답에서 필요한 데이터만 추출
    private List<SearchResultDTO> parseResults(String responseBody) {
        List<SearchResultDTO> results = new ArrayList<>();
        JSONObject jsonResponse = new JSONObject(responseBody);
        JSONArray items = jsonResponse.optJSONArray("items");

        if (items == null || items.isEmpty()) {
            return results; // 🔹 검색 결과 없음 → 빈 배열 반환
        }

        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.getJSONObject(i);
            SearchResultDTO result = new SearchResultDTO(
                    i, // 🔹 index 값을 ID로 저장
                    item.optString("address", "주소 없음"),
                    item.optString("title", "이름 없음"),
                    item.optString("mapx", "0"),
                    item.optString("mapy", "0")
            );
            results.add(result);
        }
        return results;
    }

    // 🔹 3. 사용자가 특정 장소를 선택할 수 있도록 API 추가
    @PostMapping(value = "/select", produces = "application/json; charset=UTF-8")
    public ResponseEntity<?> selectLocation(@RequestParam(name = "id") int id) {
        synchronized (selectedResults) {
            if (id >= 0 && id < selectedResults.size()) {
                return ResponseEntity.ok(selectedResults.get(id));
            } else {
                return ResponseEntity.badRequest().body("❌ 유효하지 않은 ID입니다.");
            }
        }
    }

    // 🔹 4. 검색 결과 저장 기능 추가
    @PostMapping(value = "/store_results")
    public ResponseEntity<String> storeResults(@RequestParam(name = "text") String text) {
        ResponseEntity<?> response = search(text);
        if (response.getBody() instanceof List) {
            synchronized (selectedResults) {
                selectedResults.clear();
                selectedResults.addAll((List<SearchResultDTO>) response.getBody());
            }
            return ResponseEntity.ok("✅ 검색 결과 저장 완료.");
        }
        return ResponseEntity.badRequest().body("❌ 검색 결과 저장 실패.");
    }

    // 🔹 5. API 호출 중 발생하는 예외 처리
    private ResponseEntity<String> handleApiException(WebClientResponseException e) {
        int statusCode = e.getRawStatusCode();
        String responseBody = e.getResponseBodyAsString();

        if (statusCode == 400) {
            if (responseBody.contains("SE01")) {
                return ResponseEntity.badRequest().body("❌ 잘못된 쿼리 요청. URL 및 파라미터 확인 필요.");
            } else if (responseBody.contains("SE02")) {
                return ResponseEntity.badRequest().body("❌ display 값 오류 (허용 범위: 1~100).");
            } else if (responseBody.contains("SE03")) {
                return ResponseEntity.badRequest().body("❌ start 값 오류 (허용 범위: 1~1000).");
            } else if (responseBody.contains("SE04")) {
                return ResponseEntity.badRequest().body("❌ sort 값 오류. 올바른 값인지 확인 필요.");
            } else if (responseBody.contains("SE06")) {
                return ResponseEntity.badRequest().body("❌ 잘못된 인코딩. 검색어는 UTF-8로 인코딩해야 합니다.");
            }
        } else if (statusCode == 404 && responseBody.contains("SE05")) {
            return ResponseEntity.status(404).body("❌ 존재하지 않는 검색 API. API URL 확인 필요.");
        } else if (statusCode == 500 && responseBody.contains("SE99")) {
            return ResponseEntity.status(500).body("❌ 네이버 API 서버 오류 발생.");
        }

        return ResponseEntity.status(statusCode).body("❌ 알 수 없는 오류 발생: " + responseBody);
    }
}

// 🔹 6. WebClient Bean 등록 (효율적인 관리)
@Configuration
class WebClientConfig {

    @Bean
    public WebClient webClient() {
        return WebClient.builder()
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("X-Naver-Client-Id", "MIblwPA2k1GwlHMHJteg")
                .defaultHeader("X-Naver-Client-Secret", "yxvyxR2VxY")
                .build();
    }
}
