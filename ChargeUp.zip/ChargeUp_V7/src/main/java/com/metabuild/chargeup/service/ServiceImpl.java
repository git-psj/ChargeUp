package com.metabuild.chargeup.service;

import com.metabuild.chargeup.dto.ChargeInfoDTO;
import com.metabuild.chargeup.mapper.chargeMapper;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@org.springframework.stereotype.Service("serviceImpl")
public class ServiceImpl implements Service{
    @Inject
    private chargeMapper mapper;

    @Override
    public List<ChargeInfoDTO> getStationsByAddr(String addr) {
        return mapper.getStationsByAddr(addr);
    }

    @Override
    public List<ChargeInfoDTO> getStationByStatNm(String statNm) {
        log.info("statNm ====> {}", statNm);
        return mapper.getStationByStatNm(statNm);
    }

    @Override
    public List<Map<String, Object>> getStationByFilter(HashMap<String, Object> filter) {
        log.info("$$filter ==== {}", filter);
        return mapper.getStationByFilter(filter);
    }

    @Override
    public List<Map<String, String>> getSidoCode() {
        return mapper.getSidoCode();
    }

    @Override
    public List<Map<String, String>> getSigunguCode(String sidoCode) {
        return mapper.getSigunguCode(sidoCode);
    }

    @Override
    public List<ChargeInfoDTO> getStationByZscode(String zscode) {
        return mapper.getStationByZscode(zscode);
    }

    @Override
    public List<ChargeInfoDTO> getChargeInfo(String statId) {
        return mapper.getChargeInfo(statId);
    }

    @Override
    public List<ChargeInfoDTO> getCharges(List<String> listStatId) {
        return mapper.getCharges(listStatId);
    }


}
