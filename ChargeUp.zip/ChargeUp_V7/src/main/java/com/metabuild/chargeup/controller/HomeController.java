package com.metabuild.chargeup.controller;
//POJO (Plain Old Java Object)

import com.metabuild.chargeup.GetStatus;
import com.metabuild.chargeup.dto.ChargeInfoDTO;
import com.metabuild.chargeup.dto.UserDTO;
import com.metabuild.chargeup.service.Service;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.*;

@Controller
@Slf4j
public class HomeController {

    @Inject
    private Service service;

    @GetMapping("/search") // 충전소 조회
    public String showSearchPage(HttpSession session, Model model) throws IOException, ParserConfigurationException, SAXException {
        UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
        log.debug("login======{}", loginUser);
        if(loginUser != null)
            model.addAttribute("userId", loginUser.getUserId());
        List<Map<String, String>> sido = service.getSidoCode();
        log.info("시도코드 ==== {}", sido);
        model.addAttribute("sido", sido);
        return "home";
    }

    @ResponseBody
    @PostMapping("/search") // 필터 적용
    public Map<String, Object> changeStat(@RequestParam String stat,
                                          @RequestParam String parkingFree,
                                          @RequestParam("select") List<Integer> selects,
                                          Model model) {
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("stat", stat);
        responseData.put("parkingFree", parkingFree);
        responseData.put("selects", selects);
        return responseData; // JSON 데이터로 응답 반환
    }

    @ResponseBody // 검색어로 검색
    @GetMapping(value = "/searchWord", produces = "application/json")
    public List<ChargeInfoDTO> search(@RequestParam String query,
                                      @RequestParam boolean checked) {
        log.info("$$checked===={}", checked);
        return checked? service.getStationsByAddr(query): service.getStationByStatNm(query);
    }

    @ResponseBody // 지역으로 검색
    @GetMapping(value = "/searchCode", produces = "application/json")
    public List<ChargeInfoDTO> searchCode(@RequestParam String query) {
        log.info("시도코드 === {}", query);
        return service.getStationByZscode(query);
    }

    @ResponseBody // 시군구 정보 조회
    @GetMapping("/getSigungu")
    public List<Map<String, String>> getSigungu(@RequestParam String sidoCode) {
        List<Map<String, String>> sigungu = service.getSigunguCode(sidoCode);
        return sigungu;
    }

    @ResponseBody   // 필터에 맞는 데이터 조회
    @GetMapping("/api/stations")
    public List<Map<String, Object>> getStations(@RequestParam String stat,
                                                 @RequestParam String parkingFree,
                                                 @RequestParam String selects) {
        HashMap<String, Object> filter = new HashMap<>();
        filter.put("stat", stat);
        filter.put("parkingFree", parkingFree);
        Set<String> chgerTypes = new HashSet<String>();
        log.debug("$selects   = {}", selects);
        log.debug("$equals   = {}", !selects.equals("1,1,1,1"));
        if(!selects.equals("1,1,1,1")) {
            if (selects.charAt(0) == '1') {
                chgerTypes.add("01");
                chgerTypes.add("03");
                chgerTypes.add("05");
                chgerTypes.add("06");
            }
            if (selects.charAt(2) == '1') {
                chgerTypes.add("02");
            }
            if (selects.charAt(4) == '1') {
                chgerTypes.add("04");
                chgerTypes.add("05");
                chgerTypes.add("06");
                chgerTypes.add("08");
            }
            if (selects.charAt(6) == '1') {
                chgerTypes.add("03");
                chgerTypes.add("06");
                chgerTypes.add("07");
            }
        }
        log.debug("chgerTypes == {}", chgerTypes);
        filter.put("chgerTypes", chgerTypes);
        List<Map<String, Object>> stations = service.getStationByFilter(filter);
        log.info("stations =={}", stations.size());
        return stations;
    }

    @ResponseBody   // 클릭 시 해당 충전소 정보 조회
    @GetMapping("/showInfo")
    public List<Map<String, Object>> getInfoAjax(@RequestParam(required = false) String statid,
                                                 @RequestParam(required = false) List<String> listStatId) throws IOException, ParserConfigurationException, SAXException {
        log.debug("statID === {} ", statid);
        Map<String, String> statusDescriptions = new HashMap<>();
        statusDescriptions.put("1", "통신이상");
        statusDescriptions.put("2", "사용가능");
        statusDescriptions.put("3", "충전중");
        statusDescriptions.put("4", "운영중지");
        statusDescriptions.put("5", "점검중");
        statusDescriptions.put("9", "확인불가");

        List<Map<String, Object>> result = new ArrayList<>();
        if(statid != null) {
            Map<String, Object> info = new HashMap<>();
            List<ChargeInfoDTO> dto = service.getChargeInfo(statid);
            List<Map<Integer, Map<String, String>>> status = GetStatus.getStatus(statid);
            info.put("dto", dto);
            info.put("status", status);
            info.put("statusDescriptions", statusDescriptions);
            result.add(info);
        }
        if(listStatId != null){
            log.debug("listStatId==={}", listStatId);
            log.debug("개수=={}", listStatId.size());
            List<ChargeInfoDTO> dtos = service.getCharges(listStatId);
            log.debug("개수 {} dtos ====={}", dtos.size(), dtos);
            for(ChargeInfoDTO dto : dtos){
                Map<String, Object> info = new HashMap<>();
                log.debug("dto====={}", dto);
                List<Map<Integer, Map<String, String>>> status = GetStatus.getStatus(dto.getStatId());
                info.put("dto", dto);
                info.put("status", status);
                info.put("statusDescriptions", statusDescriptions);
                result.add(info);
            }
        }
        log.debug("결과==={}", result);

        return result;
    }


}
