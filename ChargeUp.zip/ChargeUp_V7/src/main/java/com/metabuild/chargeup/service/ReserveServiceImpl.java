package com.metabuild.chargeup.service;

import com.metabuild.chargeup.dto.ReserveInfoDTO;
import com.metabuild.chargeup.mapper.ReserveMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
public class ReserveServiceImpl implements ReserveService {

    @Autowired
    private ReserveMapper reserveMapper;

    @Override
    public boolean reserveChargingStation(ReserveInfoDTO reservation) {
        try {

            // 예약번호 먼저 생성
            String reservationId = generateShortReservationId();
            reservation.setReservationId(reservationId); // 예약번호 설정

            // 🔹 로그 추가: `reservationId`가 정상적으로 생성되는지 확인
            System.out.println("Generated reservationId (Before DB Insert): " + reservationId);

            int count = reserveMapper.checkDuplicateReservation(
                    reservation.getStatid(),
                    reservation.getChgerid(),
                    reservation.getReserveDate(),
                    reservation.getReserveTime(),
                    reservation.getReservationId());

            if (count > 0) {
                return false; // 이미 예약된 시간
            }
            log.debug("$reservation===={}", reservation.getStatid());
            log.debug("$reservation===={}", reservation.getReserveDate());
            log.debug("$reservation===={}", reservation.getChgerid());
            log.debug("$reservation===={}", reservation.getUserId());
            log.debug("$reservation===={}", reservation.getReserveTime());
            reserveMapper.insertReservation(reservation);
            return true;
        } catch (Exception e) {
            e.printStackTrace(); // 예외 전체 출력
            throw new RuntimeException("예약 처리 중 오류 발생: " + e.getMessage());
        }
    }

    private String generateShortReservationId() {
        // UUID를 생성하고, "-"를 제거한 후 8자리만 사용
        String uuid = UUID.randomUUID().toString().replace("-", "");
        return uuid.substring(0, 8); // 8자리만 반환
    }
}