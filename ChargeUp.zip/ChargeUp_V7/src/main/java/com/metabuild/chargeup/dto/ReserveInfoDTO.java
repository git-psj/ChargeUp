package com.metabuild.chargeup.dto;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class ReserveInfoDTO {
    private String statid;
    private String chgerid;
    private String userId;
    private String reservationId;
    private String reserveDate;
    private String reserveTime;
    private Timestamp createdAt;

    // Getter와 Setter
    public String getStatid() {
        return statid;
    }

    public void setStatid(String statid) {
        this.statid = statid;
    }

    public String getChgerid() {
        return chgerid;
    }

    public void setChgerid(String chgerid) {
        this.chgerid = chgerid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getReserveTime() {
        return reserveTime;
    }

    public void setReserveTime(String reserveTime) {
        this.reserveTime = reserveTime;
    }

    public String getReserveDate() {
        return reserveDate;
    }

    public void setReserveDate(String reserveDate) {
        this.reserveDate = reserveDate;
    }

    public String getReservationId() { return reservationId; }

    public void setReservationId(String reservationId) { this.reservationId = reservationId;}
}