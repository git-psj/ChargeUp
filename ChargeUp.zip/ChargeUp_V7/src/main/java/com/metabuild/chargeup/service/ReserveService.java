package com.metabuild.chargeup.service;

import com.metabuild.chargeup.dto.ReserveInfoDTO;

public interface ReserveService {
    boolean reserveChargingStation(ReserveInfoDTO reservation);
}
