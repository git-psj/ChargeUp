package com.metabuild.chargeup.service;

import com.metabuild.chargeup.NoMemberException;
import com.metabuild.chargeup.dto.CombinedDTO;
import com.metabuild.chargeup.dto.PagingDTO;
import com.metabuild.chargeup.dto.ReserveInfoDTO;
import com.metabuild.chargeup.dto.UserDTO;
import com.metabuild.chargeup.mapper.UserMapper;
import com.metabuild.chargeup.mapper.chargeMapper;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service("UserServiceImpl")
public class UserServiceImpl implements UserService {

    @Inject
    private chargeMapper mapper;
    @Inject
    private UserMapper userMapper;
    @Inject
    private PasswordEncoder bcryptEncoder;

    @Override
    public int insertMember(UserDTO user) {
        //비밀번호 암호화
        String encodePasswd=bcryptEncoder.encode(user.getPassword());
        log.info("encodePasswd==={}",encodePasswd);
        user.setPassword(encodePasswd);//암호화된 비번으로 설정
        return userMapper.insertMember(user);
    }

    @Override
    public int deleteMember(String userId) {
        return userMapper.deleteMember(userId);
    }

    @Override
    public UserDTO findByUserId(String userId) {
        return userMapper.findByUserId(userId);
    }

    @Override
    public boolean idCheck(String userId) {
        log.debug("체크");
        UserDTO user = userMapper.findByUserId(userId);
        log.debug("user ==== {}", user);
        //userId가 이미 있다면 ==> user객체 반환
        //         없다면 ==> null을 반환
        if(user==null) return true; //userId사용 가능
        return false;//사용 불가
    }
    @Override
    public UserDTO loginCheck(UserDTO tmpUser)
            throws NoMemberException
    {
        log.debug("$tmpUser==={}", tmpUser);
        //userId로 회원정보 가져오기
        UserDTO user=this.findByUserId(tmpUser.getUserId());
        log.debug("$usr ===={}", user);
        if(user==null) throw new NoMemberException("아이디 또는 비밀번호가 일치하지 않습니다");
        //아이디는 맞으나 비밀번호를 체크해야 함
        String dbPwd=user.getPassword();//암호화된 비빌번호
        log.debug("$pwd = {} {}",tmpUser.getPassword(), dbPwd);
        if(!bcryptEncoder.matches(tmpUser.getPassword(), dbPwd)){
            throw new NoMemberException("아이디 또는 비밀번호가 일치하지 않습니다");
        }
        return user;//회원 인증을 받은 경우
    }

    @Override
    public List<CombinedDTO>findReserve(String userId, PagingDTO paging) {
        List<CombinedDTO>  reserve = userMapper.findReserve(userId, paging);
        log.debug("$reser ===={}", reserve);
        return reserve;
    }

    @Override
    public int getTotalCount(String userId) {
        return userMapper.getTotalCount(userId);
    }

    @Override
    public int deleteReserve(ReserveInfoDTO dto) {
        return userMapper.deleteReserve(dto);
    }
}
