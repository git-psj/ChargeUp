var markers = [];
var map;
var markerClustering;
var bounds;
var lat;
var lng;

navigator.geolocation.getCurrentPosition( // 사용자의 위치 정보를 가져옴
    (position) => {
        lat = position['coords']['latitude'];
        lng = position['coords']['longitude'];
        initMap(lat, lng);
    },
    (error) => {
        initMap(37.5665, 126.9780);
    }
);

function initMap(lat, lng) { // 지도 그리기
     map = new naver.maps.Map('map', {
        center: new naver.maps.LatLng(lat, lng),
        zoom: 12,
        zoomControl: true
    });

    markerClustering = new MarkerClustering({
        map: map,
        maxZoom: 16,
        markers: [],
        gridSize: 150,
        disableClickZoom: false,
        minClusterSize: 2,
        icons: [
            {
                content: `
                <div style="position: relative; width: 40px; height: 40px;">
                    <img src='images/cluster-marker-1.png' style="width: 100%; height: 100%;">
                    <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 14px;">
                    </span>
                </div>
            `,
                size: new naver.maps.Size(40, 40),
                anchor: new naver.maps.Point(20, 20)
            },
            {
                content: `
                <div style="position: relative; width: 40px; height: 40px;">
                    <img src='images/cluster-marker-2.png' style="width: 100%; height: 100%;">
                    <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 14px;">
                    </span>
                </div>
            `,
                size: new naver.maps.Size(40, 40),
                anchor: new naver.maps.Point(20, 20)
            },
            {
                content: `
                <div style="position: relative; width: 40px; height: 40px;">
                    <img src='images/cluster-marker-3.png' style="width: 100%; height: 100%;">
                    <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 14px;">
                    </span>
                </div>
            `,
                size: new naver.maps.Size(40, 40),
                anchor: new naver.maps.Point(20, 20)
            },
            {
                content: `
                <div style="position: relative; width: 40px; height: 40px;">
                    <img src='images/cluster-marker-4.png' style="width: 100%; height: 100%;">
                    <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 14px;">
                    </span>
                </div>
            `,
                size: new naver.maps.Size(40, 40),
                anchor: new naver.maps.Point(20, 20)
            },
            {
                content: `
                <div style="position: relative; width: 40px; height: 40px;">
                    <img src='images/cluster-marker-5.png' style="width: 120%; height: 100%;">
                    <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 14px;">
                    </span>
                </div>
            `,
                size: new naver.maps.Size(40, 40),
                anchor: new naver.maps.Point(20, 20)
            }
        ],
        indexGenerator: [10, 100, 200, 500, 1000],
        stylingFunction: function (clusterMarker, count) {
        // 클러스터 마커의 DOM 엘리먼트를 가져옵니다.
        var clusterElement = clusterMarker.getElement();

        // 숫자를 <span>에 동적으로 삽입합니다.
        var spanElement = clusterElement.querySelector("span");
        if (spanElement) {
            spanElement.textContent = count;
        }
        }
    });

    // 보이는 곳 좌표
    bounds = map.getBounds(),
        southWest = bounds.getSW(),
        northEast = bounds.getNE(),
        lngSpan = northEast.lng() - southWest.lng(),
        latSpan = northEast.lat() - southWest.lat();
}

function showloading(){
    console.log("로딩--")
    const loading_page = document.getElementById("load");
    loading_page.style.display = 'block';
}
function closeloading(){
    console.log("로딩")
    const loading_page = document.getElementById("load");
    loading_page.style.display = 'none';
}

function getMarker(data){
    showloading();
    fetch('/api/stations?stat=' + data.stat + '&parkingFree=' + data.parkingFree + '&selects=' + data.selects.join(','))
        .then(response => response.json())
        .then(data => {
             markers = data.map(station => {
                var marker = new naver.maps.Marker({
                    position: new naver.maps.LatLng(station.LAT, station.LNG),
                    title: station.STATID,
                    zIndex : 100
                });
                var infoWindow = new naver.maps.InfoWindow({
                    content: `<div><strong>${station.STATID}</strong></div>`
                });
                naver.maps.Event.addListener(marker, 'click', function() {
                    console.log("인포", infoWindow);
                    if(infoWindow.getMap())
                        infoWindow.close();
                    else
                       infoWindow.open(map, marker);
                    getinfo(station.STATID);
                });
                naver.maps.Event.addListener(map, 'idle', function() {
                    infoWindow.close();
                    closePopup('infoContent');
                });
                return marker;
            });
            markerClustering.setMarkers(markers);
            console.log("클러스터링");
            closeloading();
//            updateMarkers(map, markers);
        })
        .catch(error => console.error('Error loading stations:', error));
}

function getinfo(statid){
    showloading();
    openPopup('infoContent');
    fetch(`/showInfo?statid=${statid}`)
        .then(response => response.json())
            .then(data => {
                console.log("데이터 : ", data)
                const infoContent = document.querySelector("#infoContent");
                infoContent.style.display = 'block';
                const popupHeader = infoContent.querySelector(".popupHeader");
                popupHeader.innerHTML = "";
                popupHeader.innerHTML = `<button onclick="closePopup('infoContent')"> < </button><h5>${data[0].dto[0].statNm}</h5>`;
                const allInfo = document.querySelector(".allInfo");
                const info = allInfo.querySelector(".info");
                info.innerHTML = "";
                const fast = allInfo.querySelector(".fast");
                fast.innerHTML = "";
                const slow = allInfo.querySelector(".slow");
                slow.innerHTML = "";
                const none = allInfo.querySelector(".none");
                none.innerHTML = "";
                const detail = allInfo.querySelector(".detail");
                detail.innerHTML = "";
                info.innerHTML = `<p>${data[0].dto[0].bnm} | 거리km</p>
                                    <h5>${data[0].dto[0].statNm}</h5>
                                    <span id="addr">${data[0].dto[0].addr}</span>
                                    <button class="copy" onclick="copy()">▶</button><br>`;
                if(data[0].dto[0].limitYn == 'N')
                    info.innerHTML += `<button class="option" disabled>완전개방</button>`;
                if(data[0].dto[0].parkingFree == 'Y')
                    info.innerHTML += `<button class="option" disabled>무료주차</button>`;
                info.innerHTML += `<hr><h5>충전기 정보</h5>`;
                var count1 = 1
                var count2 = 1
                var count3 = 1
                data[0].dto.forEach(function(item, index) {
                    if(item.output != 'None') {
                        if(Number(item.output) >= 50) {
                            console.log("index: ", index)
                            updateInfo("급속", count1, item, index, data[0], fast);
                            count1++;
                        }else{
                            updateInfo("완속", count2, item, index, data[0], slow)
                            count2++;
                        }
                    }else {
                        updateInfo("충전기", count3, item, index, data[0], none)
                        count3++;
                    }
                });
                let location = (data[0].dto[0].location == 'null')? "확인 불가": data[0].dto[0].location;
                let parkingFree = (data[0].dto[0].parkingFree == 'Y')? "무료": "유료";
                let useInfo = (data[0].dto[0].note != 'None')? data[0].dto[0].note: "";
                useInfo += (data[0].dto[0].limitDetail != 'None')? data[0].dto[0].limitDetail: "";
                useInfo += (data[0].dto[0].delDetail != 'None')? data[0].dto[0].delDetail: "";
                useInfo = (useInfo == "")? "확인 불가": useInfo;
                let chgerType = (count1 > 1)? "급속" :"확인불가"
                chgerType += (chgerType != "확인불가")? ((count2 > 1)? "/완속": ""): ((count2 > 1)? "완속": "");
                detail.innerHTML += `<h5>충전소 정보</h5>
                                            <div class="detailInfo"><span>상세위치</span><span>${location}</span></div>
                                            <div class="detailInfo"><span>운영기관</span><span>${data[0].dto[0].busiNm}</span></div>
                                            <div class="detailInfo"><span>연락처</span><span>${data[0].dto[0].busiCall}</span></div>
                                            <div class="detailInfo"><span>충전기 유형</span><span>${chgerType}</span></div>
                                            <div class="detailInfo"><span>주차비</span><span>${parkingFree}</span></div>
                                            <div class="detailInfo"><span>운영시간</span><span>${data[0].dto[0].useTime}</span></div>
                                            <div class="detailInfo"><span>이용정보</span><span>${useInfo}</span></div>
                                            `;
            });
    closeloading();

}
function updateInfo(speed, count, item, index, data, div){
    console.log("충전소 data, 상태 :", data)
//    console.log("인덱스: ", index);
//    console.log("상태값: ", data.status[index][index+1].stat);
    let resultItem = document.createElement("div");
    resultItem.className = "chgerInfo";
    var output = (speed != 'None')? item.output: "-";
    var countNum = (count.toString().length > 9)? count: "0" + count;
    resultItem.innerHTML = `<div class="detailInfo"><h5>${speed} ${countNum}</h5>
                                <h5>${data.statusDescriptions[data.status[index][index+1].stat]} ${output}kWh</h5>
                            </div>
                                <p>충전기 ID : ${item.statId}${item.chgerId}</p>
                                <div class="chgerTypes">
                                    <p id="DC1_${index}">DC차데모</p>
                                    <p id="AC1_${index}">AC완속</p>
                                    <p id="DC2_${index}">DC콤보</p>
                                    <p id="AC2_${index}">AC3상</p>
                                </div>`;
    if(data.status[index][index+1].stat == '3'){
        let nowTsdt = data.status[index][index+1].nowTsdt
        let formattedDateString = nowTsdt.slice(0, 4) + "-" + nowTsdt.slice(4, 6) + "-" + nowTsdt.slice(6, 8) + " " +
                                  nowTsdt.slice(8, 10) + ":" + nowTsdt.slice(10, 12) + ":" + nowTsdt.slice(12, 14);
        resultItem.innerHTML += `<div class="detailInfo"><p>충전중 시작일시</p><p>${formattedDateString}</p></div>`
    }
//    resultItem.innerHTML += `<button class="book" onclick="book('${item.statId}', '${item.chgerId}')">예약</button><hr>`
//    resultItem.innerHTML += `<button class="book" onclick="openReservePopup()">예약</button><hr>`
    resultItem.innerHTML += `<button class="book" onclick="bok('${item.statId}', '${item.chgerId}')">예약</button><hr>`
    div.appendChild(resultItem)
    document.getElementById('DC1_'+ index).classList.toggle("exist", item.chgerType == '01' || item.chgerType == '03' || item.chgerType == '05' || item.chgerType == '06');
    document.getElementById('AC1_'+ index).classList.toggle("exist", item.chgerType == '02');
    document.getElementById('DC2_'+ index).classList.toggle("exist", item.chgerType == '04' || item.chgerType == '05' || item.chgerType == '06' || item.chgerType == '08');
    document.getElementById('AC2_'+ index).classList.toggle("exist", item.chgerType == '03' || item.chgerType == '06' || item.chgerType == '07');

}


naver.maps.Event.addListener(map, 'idle', function() {
//    console.log("움직");
    updateMarkers(map, markers);
});

function updateMarkers(map, markers) {
    console.log("업데이트");
    var mapBounds = map.getBounds();
    var marker, position;
    for (var i = 0; i < markers.length; i++) {
        marker = markers[i];
        position = marker.getPosition();
        if (mapBounds.hasLatLng(position)) {
            showMarker(map, marker);
        } else {
            hideMarker(map, marker);
        }
    }

}
function showMarker(map, marker) { // 마커 보기
    if (marker.getMap()) return;
    marker.setMap(map);
}
function hideMarker(map, marker) { // 마커 숨기기
    if (!marker.getMap()) return;
    marker.setMap(null);
}

function copy() {
    var copyAddr = document.getElementById("addr").textContent;
    const textArea = document.createElement('textarea');
    document.body.appendChild(textArea);
    textArea.value = copyAddr;
    textArea.select();
    window.navigator.clipboard.writeText(textArea.value);
}

function bok(statid, chgerid) {
    const popup = document.getElementById('reservePopup');
    if (popup) {
        const userId = document.getElementById('userId').value;
        if (!userId) {  // userId가 없을 경우
            const userConfirmed = confirm("로그인이 필요합니다. 로그인 페이지로 이동하시겠습니까?");
            if (userConfirmed) {
                window.location.href = '/login';  // 로그인 페이지로 이동
            } else {
                // 사용자가 취소를 선택하면 팝업을 닫고 이전 페이지로 돌아가도록 설정
                return;
            }
        }
        popup.style.display = 'flex';
        document.getElementById('statid').value = statid;
        document.getElementById('chgerid').value = chgerid;
    } else {
        console.error('예약 팝업을 찾을 수 없습니다.');
    }
}

function submitReservation() {
    console.log("예약------------------")
    const statid = document.getElementById('statid').value;
    const chgerid = document.getElementById('chgerid').value;
    const userId = document.getElementById('userId').value;
    const reserveDate = document.getElementById('reserveDate').value; // 날짜 값
    const reserveTime = document.getElementById('reserveTime').value; // 시간 값
    console.log(statid, chgerid, reserveDate, reserveTime)

    if (!reserveDate || !reserveTime) {
        alert('날짜와 시간을 모두 입력해주세요.');
        return;
    }

    fetch('/api/reservation/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            statid,
            chgerid,
            userId,
            reserveDate,
            reserveTime,
        }),
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                alert(data.message);
            } else {
                alert(data.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            alert('예약 처리 중 오류가 발생했습니다.');
        });
}

var previousMarker = null;
var previousNewMarker = null;

function move(statId, lat, lng){ // 텍스트 클릭 시 해당 충전소 위치로 이동
    var marker = markers.find(marker => marker.getTitle() == statId); // 해당 마커 찾기
    if(previousMarker){ // 이전에 클릭한 마커 원래대로
        previousMarker.setIcon(null);
    }
    if(previousNewMarker){ // 이전에 만든 마커 없애기
        removeMarkerByTitle(previousNewMarker);
    }
    if (marker) { // 마커가 있는 경우 디자인 변경
        console.log("있음")
        marker.setIcon({
           url: '/images/rb_25530.png',
             size: new naver.maps.Size(30, 45),
             scaledSize: new naver.maps.Size(30, 45),
             origin: new naver.maps.Point(0, 0),
             anchor: new naver.maps.Point(15, 45)
        })
    }else { // 마커가 없는 경우 마커 생성
        addMarker(statId, lat, lng);
        previousNewMarker = statId;
    }
    // 지도 중심 이동
    map.setCenter(new naver.maps.LatLng(lat, lng));
    map.setZoom(18, true); // 줌 레벨도 조정 가능
    previousMarker = marker;
}

function addMarker(statId, lat, lng){
    console.log("마커 생성합시다.")
    var newMarker = new naver.maps.Marker({
        position: new naver.maps.LatLng(lat, lng),
        title: statId,
        zIndex: 110,
        icon: {
                url: '/images/rb_25530.png',
                   size: new naver.maps.Size(30, 45),
                   scaledSize: new naver.maps.Size(30, 45),
                   origin: new naver.maps.Point(0, 0),
                   anchor: new naver.maps.Point(15, 45)
            }
    });
    // 마커 배열에 추가
    markers.push(newMarker);
    return newMarker;
}

function removeMarkerByTitle(markerTitle) {
    // markers 배열에서 해당 title을 가진 마커 찾기
    const markerIndex = markers.findIndex(marker => marker.getTitle() === markerTitle);

    if (markerIndex !== -1) {
        markers[markerIndex].setMap(null); // 지도에서 제거
        markers.splice(markerIndex, 1); // 배열에서도 제거
    }
}