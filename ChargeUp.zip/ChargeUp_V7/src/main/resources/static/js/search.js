let popupStates = {}; // 팝업 상태 저장
let selects = new Array(4).fill(1);

let tempMap = {};
let prevMap = {};

function initializeButtonStates() { // 버튼 값 tempMap에 저장
    const selectButtons = document.querySelectorAll('button[id^="chgerType0"]');
    tempMap["selects"] = []; // tempMap 초기화
    selectButtons.forEach((btn) => {
        const isSelected = btn.classList.contains("medium");
        tempMap["selects"].push(isSelected ? 1 : 0);
    });
    const statButton = document.getElementById('statButton');
    if (statButton) {
        tempMap["stat"] = statButton.getAttribute('data-stat') === '1' ? '1' : '0';
    }
    const parkingFreeButton = document.getElementById('parkingFreeButton');
    if (parkingFreeButton) {
        tempMap["parkingFree"] = parkingFreeButton.getAttribute('data-parkingFree') === '1' ? '1' : '0';
    }
    prevMap = { ...tempMap };
    applyStatFilter();
}

document.addEventListener("DOMContentLoaded", function () { // 페이지 로드 시 실행
    initializeButtonStates();
});

function openPopup(popupId) { // 팝업 열기
    const popup = document.getElementById(popupId);
    console.log("popup", popupId, popup)
    const allInfo = document.querySelector('.allInfo');
    allInfo.scrollTop = 0;
    if (popupStates[popupId] === 'block' && popupId != 'infoContent') {
        closePopup(popupId);
    } else {
        popup.style.display = 'block';
        popupStates[popupId] = 'block';
    }
    if(popupId == 'resultContent' || popupId == 'infoContent'){
        closePopup('searchContents')
        closePopup((popupId == 'resultContent')? 'infoContent': 'resultContent')
    }
}

function closePopup(popupId) { // 팝업 닫기
    const popup = document.getElementById(popupId);
    popup.style.display = 'none';
    popupStates[popupId] = 'none';
    if((popupId == 'resultContent' || popupId == 'infoContent') && Object.values(popupStates).indexOf('block') == -1){
        openPopup('searchContents')
    }
    const selectButtons = document.querySelectorAll('button[id^="chgerType0"]');
    selectButtons.forEach((button, index) => {
        if (prevMap["selects"][index] === 1) {
            button.classList.add("medium");
            button.classList.remove("thin");
        } else {
            button.classList.add("thin");
            button.classList.remove("medium");
        }
    });
}
var polyline = "";
var dashedLine = "";
var dashedLine2 = "";

function openContent(searchId){
    const routeResultContent = document.getElementById("routeResultContent");
    routeResultContent.style.display = 'none';
    console.log("클릭--", searchId)
    if(searchId == 'sidoContent'){
        console.log("시도--")
        const popup = document.getElementById('sidoContent');
        popup.style.display = 'block';
        const popup2 = document.getElementById('routeContent');
        popup2.style.display = 'none';
        polyline.setMap(null);
        dashedLine.setMAp(null);
        dashedLine2.setMAp(null);
        removeMarkerByTitle('start');
        removeMarkerByTitle('goal');
    }else{
        console.log("경로--")
        const popup = document.getElementById('sidoContent');
        popup.style.display = 'none';
        const popup2 = document.getElementById('routeContent');
        popup2.style.display = 'block';
    }
}

function resetFilter(id) { // 필터 초기화
    console.log("id : ", id)
    if(id == "all")
        tempMap['stat'] = 0
        tempMap['parkingFree'] = 0
        document.querySelector("#statButton").classList.remove('medium');
        document.querySelector("#statButton").classList.add("thin");
        document.querySelector("#parkingFreeButton").classList.remove('medium');
        document.querySelector("#parkingFreeButton").classList.add("thin");
    tempMap["selects"] = new Array(4).fill(1);
    document.querySelectorAll('button[id^="chgerType0"]').forEach((button) => {
        button.classList.remove('thin');
        button.classList.add('medium'); // 모든 버튼을 선택된 상태로 초기화
    });
    applyStatFilter();
}

function toggle(id) { // 필터 버튼을 눌렀을 때
    const button = document.getElementById(id + 'Button');
    const currentValue = button.getAttribute('data-' + id);

    if (id === 'stat' || id === 'parkingFree') {
        if (document.getElementById('chgerTypePopup').style.display == 'block') {
            closePopup('chgerTypePopup');
        }
        tempMap[id] = currentValue === '1' ? '0' : '1';
        button.setAttribute('data-' + id, tempMap[id])
        applyStatFilter();
    } else {
        const selectButtons = document.querySelectorAll('button[id^="chgerType0"]');
        tempMap["selects"] = [];
        selectButtons.forEach((btn, index) => {
            const isSelected = btn.classList.contains("medium");
            if (btn === button) {
                const newValue = !isSelected ? 1 : 0;
                btn.classList.toggle("medium", newValue === 1);
                btn.classList.toggle("thin", newValue === 0);
            }
            tempMap["selects"].push(btn.classList.contains("medium") ? 1 : 0);
        });
    }
}

function applyStatFilter() { // 필터 버튼 적용
    prevMap = {...tempMap}
    closePopup('chgerTypePopup');
    // `tempMap`에 저장된 임시 변경 사항을 폼에 반영
    document.getElementById('statInput').value = tempMap['stat'];
    document.getElementById('parkingFreeInput').value = tempMap['parkingFree'];
    const hiddenInputs = document.querySelectorAll('input[name="select"]');
    hiddenInputs.forEach((input, index) => {
        input.value = tempMap['selects'][index];
        document.getElementById('filterForm').appendChild(input);
    });

    // 폼 데이터를 AJAX 요청으로 전송
    fetch('/search', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(new FormData(document.getElementById('filterForm'))),
        traditional: true
    })
    .then(response => response.json())  // 응답을 JSON 형태로 처리
    .then(data => {
        // 받은 JSON 데이터를 사용하여 UI 업데이트
        console.log("data : ", data);
        getMarker(data);
        updateUI(data);  // updateUI 함수로 UI 갱신
    })
    .catch(error => {
        console.error('Error during the fetch operation:', error);
    });
}

function updateUI(data) { // 바뀐 값 ui에 반영
    document.querySelector("#statButton").classList.toggle("medium", data.stat == 1);
    document.querySelector("#statButton").classList.toggle("thin", data.stat == 0);
    document.querySelector("#parkingFreeButton").classList.toggle("medium", data.parkingFree == 1);
    document.querySelector("#parkingFreeButton").classList.toggle("thin", data.parkingFree == 0);
    const selectButtons = document.querySelectorAll('button[id^="chgerType0"]');
    selectButtons.forEach((btn, index) => {
        const isSelected = data.selects[index] === 1;
        btn.classList.toggle("medium", isSelected);
        btn.classList.toggle("thin", !isSelected);
    });
}

function searchWithWord(popupId){ // 검색어로 검색
    console.log(popupStates[popupId])
    if(popupStates[popupId] != 'block' || popupStates[popupId] == undefined){
        openPopup(popupId)
    }
    document.getElementById('toggleSwitch').style.display = 'block';
    console.log(popupStates[popupId])
    // 검색어 가져오기
    const searchTerm = document.getElementById("search-box").value;
    const is_checked = document.getElementById('toggle').checked;
    console.log("checked: ", is_checked)

    console.log("searchTerm: ", searchTerm)
    // 값이 비어있는지 확인
    if (!searchTerm) {
        closePopup(popupId)
        return;
    }
    // fetch로 GET 요청 보내기
    fetch("/searchWord?query=" + encodeURIComponent(searchTerm) +"&checked=" + is_checked,{
        method: 'GET',
        headers: {
            'Accept': 'application/json',  // JSON 형식으로 응답 요청
        }})
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => {  // 오류 메시지 확인
                    throw new Error("검색에 실패했습니다: " + text);
                });
            }
            return response.json();  // 서버에서 JSON 응답을 받음
        })
        .then(data => {
            console.log(data);  // 서버에서 받은 데이터 확인용
            updateSearchResults(data);
        })
        .catch(error => {
            alert(error.message);  // 오류 처리
        });
};

function searchWithCode(popupId){ // 행정구역으로 검색
    console.log(popupStates[popupId])
    if(popupStates[popupId] != 'block' || popupStates[popupId] == undefined){
        openPopup(popupId)
    }
    document.getElementById("toggleSwitch").style.display = 'none';
    // 검색어 가져오기
    const searchTerm = document.getElementById("sigunguSelect").value;
    console.log("searchTerm: ", searchTerm)
    // 값이 비어있는지 확인
    if (!searchTerm) {
        alert("지역을 선택해주세요.");
        return;
    }
    // fetch로 GET 요청 보내기
    fetch("/searchCode?query=" + encodeURIComponent(searchTerm),{
        method: 'GET',
        headers: {
            'Accept': 'application/json',  // JSON 형식으로 응답 요청
        }})
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => {  // 오류 메시지 확인
                    throw new Error("검색에 실패했습니다: " + text);
                });
            }
            return response.json();  // 서버에서 JSON 응답을 받음
        })
        .then(data => {
            console.log(data);  // 서버에서 받은 데이터 확인용
            updateSearchResults(data);
        })
        .catch(error => {
            alert(error.message);  // 오류 처리
        });
};

function updateSearchResults(data) { // 검색 결과 업데이트
    document.querySelector(".resultCount").value = data.length;
    const resultDiv = document.querySelector(".searchResult");
    resultDiv.innerHTML = "";  // 기존 검색 결과 초기화
    document.querySelector("#statButton").classList.toggle("medium", data.stat == 1);
    if (data.length === 0) {
        resultDiv.innerHTML = "<p>찾으시는 검색 결과가 없습니다.</p>";
    } else {
        data.forEach(function(item) {
            const resultItem = document.createElement("div");
            resultItem.innerHTML = `<h5 onclick="move('${item.statId}', '${item.lat}', '${item.lng}')">${item.statNm}</h5><p>${item.addr}</p><hr>`;
            resultDiv.appendChild(resultItem);
        });
    }
}

function updateSigungu() { // 시군구 데이터 가져오기
    var sidoCode = document.getElementById("sidoSelect").value;  // 선택된 시/도 코드
    if (sidoCode) {
        fetch(`/getSigungu?sidoCode=` + sidoCode)
            .then(response => response.json())
            .then(data => {
                // 시/군/구 select 요소 비우기
                var sigunguSelect = document.getElementById("sigunguSelect");
                sigunguSelect.innerHTML = "<option value=''>시/군/구</option>";
                // 받아온 데이터로 시/군/구 옵션 추가
                data.forEach(function(item) {
                    var option = document.createElement("option");
                    option.value = item['CODE'];
                    option.textContent = item['SIGUNGU'];
                    sigunguSelect.appendChild(option);
                });
                // 시/군/구 select 활성화
                sigunguSelect.disabled = false;
            })
            .catch(error => {
                alert("시/군/구 데이터를 불러오는 데 실패했습니다.");
            });
    } else {
        // 시/도 선택이 없으면 시/군/구 select 비활성화
        document.getElementById("sigunguSelect").disabled = true;
    }
}
function resetCode(){ // 행정구역 초기화
    document.getElementById('sidoSelect').selectedIndex = 0;
    document.getElementById('sigunguSelect').selectedIndex = 0;
    document.getElementById('sigunguSelect').disabled = true;
}
function openReservePopup() {
//    alert("오픈");

    const popup = document.getElementById('reservePopup');
    console.log(popup);
    if (popup) {
        popup.style.display = 'flex'; // 팝업 보이기
    } else {
        console.error('Element with ID "reservePopup" not found.');
    }
}

function closeReservePopup() {
    const popup = document.getElementById('reservePopup');
    if (popup) {
        popup.style.display = 'none'; // 팝업 숨기기
    } else {
        console.error('Element with ID "reservePopup" not found.');
    }
}

function confirmReservation() {
    const selectedTime = document.getElementById('reserveTime').value;
    if (selectedTime) {
        alert(`선택한 예약 시간: ${selectedTime}`);
        closeReservePopup();
    } else {
        alert('예약 시간을 선택해주세요.');
    }
}

function confirmReservation() {
    const selectedTime = document.getElementById('reserveTime').value;
    const statid = document.getElementById('statid').value; // 충전소 ID 입력 필드
    const userId = document.getElementById('userId').value; // 사용자 ID 입력 필드
    const userPw = document.getElementById('userPw').value; // 사용자 PW 입력 필드

    if (!selectedTime || !statid || !userId || !userPw) {
        alert('모든 정보를 입력해주세요.');
        return;
    }

    const reservationData = {
        statid: parseInt(statid, 10),
        userId: userId,
        userPw: userPw,
        reserveTime: selectedTime
    };

    fetch('/api/reservation/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(reservationData)
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        if (data === "예약 성공") {
            closeReservePopup();openReservePopup
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('예약 중 오류가 발생했습니다.');
    });
}

function openNearPopup() {
//    alert("오픈");

    const popup = document.getElementById('nearPopup');
    console.log(popup);
    if (popup) {
        popup.style.display = 'flex'; // 팝업 보이기
        const test = document.getElementById('test1');
    } else {
        console.error('Element with ID "nearPopup" not found.');
    }
}

function closeNearPopup() {
    const popup = document.getElementById('nearPopup');
    if (popup) {
        popup.style.display = 'none'; // 팝업 숨기기
    } else {
        console.error('Element with ID "nearPopup" not found.');
    }
}

function calculateNear()
{
    showloading();
    dest = new naver.maps.LatLng(lat, lng);
    map.setCenter(dest);
    map.setZoom(17, true);

    setTimeout(function(){
        const marketList = document.getElementsByTagName("area");
        const resultNear = document.querySelector(".searchNear");
        resultNear.innerHTML = "";  // 기존 검색 결과 초기화
        console.log("리스트", marketList);
        document.querySelector("#map > div:nth-child(1) > div > div:nth-child(1) > div:nth-child(3) > div:nth-child(2)")
        listStatId = [];
        for(i=0; i<marketList.length; i++)
        {
            console.log("반복문 시작");
            const parentId = marketList[i].parentNode.parentNode.getAttribute("title");
            listStatId.push(parentId);
            const altData = marketList[i].getAttribute("alt").split(" ")[2];
            const altLng = altData.split(",")[0];
            const altLat = altData.split(",")[1];
            const altDistance = calculateDistance(altLng, altLat);
            console.log("alt위경도 : ", altLng, altLat, altDistance)
        }
        console.log("아이디리스트", listStatId)
        getName(listStatId, resultNear);

    }, 2000);
}

function calculateDistance(Lng, Lat){
    console.log("계산", Lng, Lat)

    PI = 3.14159265358979323846;
    const tmpLng = lng * PI / 180;
    const tmpLat = lat * PI / 180;
    const tmpLng2 = Lng * PI / 180;
    const tmpLat2 = Lat * PI / 180;

    const resultDistance = 6378137 * Math.acos(Math.cos(tmpLat) * Math.cos(tmpLat2) * Math.cos(tmpLng2 - tmpLng) + Math.sin(tmpLat) * Math.sin(tmpLat2));
    console.log("계산결과", resultDistance)
    return resultDistance;
}

function getName(listStatId, resultNear)
{
    console.log("아이디 리스트 : ", listStatId);
    console.log("아이디 리스트 : ", listStatId.length);
    const searchNearHeader = document.querySelector(".searchNearHeader");
    searchNearHeader.innerHTML = `<h5>주변 충전소 ${listStatId.length}개</h5>`;
    if(listStatId.length == 0){
        const resultNearItem = document.createElement("div");
        resultNearItem.innerHTML = `<h5>주변에 충전소가 없습니다</h5>`;
        resultNear.appendChild(resultNearItem);
        openNearPopup();
        console.log("완료")
    } else {
        fetch(`/showInfo?listStatId=${listStatId}`)
            .then(response => response.json())
                .then(data => {
                    console.log("데이터", data);
                    data.forEach(function(item) {
                        console.log("item : ", item);
                        const altDistance = calculateDistance(item.dto.lng, item.dto.lat);
                        console.log("거리 : ",altDistance);
                        item.distance = Math.floor(altDistance); // 거리 정보를 객체에 추가
                        console.log("item-- : ", item);
                    });
                    console.log("data-- : ", data);
                        // 거리 기준으로 오름차순 정렬
                        data.sort(function (a, b) {
                            return a.distance - b.distance;
                        });

                        // 정렬된 데이터를 HTML에 출력
                        data.forEach(function (item) {
                            console.log("정렬된 item : ", item);

                            // 이름과 거리 정보 표시
                            const resultNearItem = document.createElement("div");
                            resultNearItem.innerHTML = `<h5>${item.dto.statNm}</h5><p>${item.distance}m</p><hr>`;
                            resultNear.appendChild(resultNearItem);
                        });
                    openNearPopup();
                    closeloading();
                    console.log("완료")
                })
                .catch(error => {
                        console.error('Error during the fetch operation:', error);
                    });

    }
}


async function getGeo(addr) {
    return new Promise((resolve, reject) => {
        naver.maps.Service.geocode({
            query: addr  // 주소 입력
        }, function(status, response) {
            if (status !== naver.maps.Service.Status.OK) {
                reject('주소를 찾을 수 없습니다!');
            }
            var result = response.v2,
                items = result.addresses;
            if (items && items.length > 0) {
                var lat = items[0].y;  // 위도
                var lng = items[0].x; // 경도
                resolve({ lat, lng });
            } else {
                reject('주소를 찾을 수 없습니다!');
            }
        });
    });
}

function msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60);
    let minutes = Math.floor((duration / (1000 * 60)) % 60);
    let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
    if(hours != 0){
        return `${hours}시간 ${minutes}분 ${seconds}초`
    } else if (minutes != 0){
        return `${minutes}분 ${seconds}초`
    } else{
        return '${seconds}초'
    }
}

async function searchRoute() {
    try {

        const start = document.getElementById("startLocation").value.trim();
        const goal = document.getElementById("goalLocation").value.trim();
        if (!start || !goal) {
            alert("출발지와 도착지를 입력해주세요.");
            return;
        }

        let startGeo = await getGeo(start);
        let goalGeo = await getGeo(goal);
//        let startGeo = await getGeo("서울 노원구 중계로 123");  // 시작지 주소
//        let goalGeo = await getGeo("서울 노원구 노해로 448");   // 도착지 주소

        let geoData = {
            start: startGeo,  // {lat, lng} 형태
            goal: goalGeo     // {lat, lng} 형태
        };

        console.log("위경도 찾기", geoData);

        const response = await fetch('/coordinates', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(geoData) // JSON 문자열로 변환
        });
        const data = await response.json();
        console.log('Response:', data);
        if (data && data.route && data.route.traoptimal && data.route.traoptimal[0]) {
            if(polyline != ""){
                polyline.setMap(null);
                removeMarkerByTitle('start');
                removeMarkerByTitle('goal');
            }
            var routePath = data.route.traoptimal[0].path;  // 응답에서 경로 가져오기
            console.log("루트 데이터 :", data.route.traoptimal[0].summary.goal.location[0])

            var goalLng = data.route.traoptimal[0].summary.goal.location[0];
            var goalLat = data.route.traoptimal[0].summary.goal.location[1];
            addMarker('goal',goalLat, goalLng );
            var startLng = data.route.traoptimal[0].summary.start.location[0];
            var startLat = data.route.traoptimal[0].summary.start.location[1];

            var distance = data.route.traoptimal[0].summary.distance // 전체 거리(m)
            var duration = data.route.traoptimal[0].summary.duration // 소요시간(ms)
            var tollFare = data.route.traoptimal[0].summary.tollFare // 통행요금
            var fuelPrice = data.route.traoptimal[0].summary.fuelPrice // 유류비

            var distanceKm = (distance < 1000) ? `${distance}m` : `${(distance / 1000).toFixed(2)}km`;

            const routeResultContent = document.getElementById("routeResultContent");
            routeResultContent.style.display = 'block';
            routeResultContent.innerHTML = "";
            routeResultContent.innerHTML = `<h5>전체 거리 : ${distanceKm}</h5>
                                            <h5>예상 소요 시간 : ${msToTime(duration)}</h5>
                                            <h5>예상 통행 요금 : ${tollFare}원</h5>
                                            <h5>예상 유류비 : ${fuelPrice}원</h5>`;

            console.log("시작 : ", startLat, startLng)
            addMarker('start', startLat, startLng);
            map.setCenter(new naver.maps.LatLng(startLat, startLng));
            map.setZoom(15, true); // 줌 레벨도 조정 가능

            // 경로를 Polyline에 맞는 형식으로 변환
            var polylinePath = routePath.map(function(coord) {
                return new naver.maps.LatLng(coord[1], coord[0]);  // [경도, 위도] -> [위도, 경도]로 변환
            });

            // 경로 그리기
             polyline = new naver.maps.Polyline({
                path: polylinePath,            // 경로 좌표 배열
                strokeColor: '#FF0000',        // 선 색상 (빨강)
                strokeOpacity: 0.8,            // 선 투명도
                strokeWeight: 6,               // 선 두께
                map: map                       // 지도에 경로 표시
            });

            var startLatLng = new naver.maps.LatLng(startLat, startLng);
            var firstRouteLatLng = polylinePath[0];
            var goalLatLng = new naver.maps.LatLng(goalLat, goalLng);
            var lastRouteLatLng = polylinePath[polylinePath.length - 1];

            dashedLine = new naver.maps.Polyline({
                path: [startLatLng, firstRouteLatLng], // 출발 위치와 첫 번째 경로 좌표
                strokeColor: '#0000FF',   // 선 색상 (파랑)
                strokeOpacity: 0.7,       // 선 투명도
                strokeWeight: 4,          // 선 두께
                strokeStyle: 'dash',    // 점선 스타일
                map: map                  // 지도에 표시
            });
            dashedLine2 = new naver.maps.Polyline({
                            path: [goalLatLng, lastRouteLatLng], // 출발 위치와 첫 번째 경로 좌표
                            strokeColor: '#0000FF',   // 선 색상 (파랑)
                            strokeOpacity: 0.7,       // 선 투명도
                            strokeWeight: 4,          // 선 두께
                            strokeStyle: 'dash',    // 점선 스타일
                            map: map                  // 지도에 표시
                        });
        } else {
            console.error('경로 데이터가 없습니다.');
        }
    } catch (error) {
        console.error('Error:', error);
    }

}


// 검색 실행 함수 (전역에서 접근 가능해야 함)
function searchLocation(type) {
    searchType = type;
    const searchTerm = document.getElementById(type + "Location").value;
    if (!searchTerm) {
        alert("검색어를 입력하세요.");
        return;
    }

    fetch(`/api/search?text=${encodeURIComponent(searchTerm)}`)
        .then(response => response.json())
        .then(data => updateSearchResult(data, type))
        .catch(error => console.error("검색 오류:", error));
}

// 🔹 검색 결과를 오른쪽 리스트에 표시
function updateSearchResult(results, type) {
    const resultDiv = document.getElementById("searchResults");
    resultDiv.innerHTML = "";

    if (results.length === 0) {
        resultDiv.innerHTML = "<p>검색 결과가 없습니다.</p>";
    } else {
        results.forEach((item, index) => {
            const resultItem = document.createElement("div");
            resultItem.classList.add("search-result-item");
            resultItem.innerHTML = `
                <h5 onclick="selectLocation('${type}', '${item.title}', '${item.address}', ${item.mapx}, ${item.mapy})">
                    ${item.address}
                </h5>
                <p>${item.title}</p><hr>
            `;
            resultDiv.appendChild(resultItem);
        });
    }

    document.getElementById("searchResultsContainer").style.display = "block"; // 결과 보이기
}

// 🔹 선택된 출발지/도착지를 입력 필드에 적용 + 검색 실행
function selectLocation(type, title, address, lat, lng) {
    // 🔹 HTML 태그 제거 (예: <b>태그 제거)
    const cleanTitle = title.replace(/<\/?[^>]+(>|$)/g, "");

    // 🔹 입력 필드에 주소 반영
    document.getElementById(type + "Location").value = cleanTitle;

    // 🔹 선택한 장소의 데이터를 저장
    window[type + "LocationData"] = { title: cleanTitle, address, lat, lng };
    console.log("검색 데이터 : ", address, lat, lng);
    // 🔹 검색창에 선택한 내용 반영 후 자동 검색 실행
//    document.getElementById("search-box").value = cleanTitle; // 🔹 검색어 입력란 업데이트

    // 🔹 검색 결과 리스트 숨기기

    document.getElementById("searchResultsContainer").style.display = "none";
}